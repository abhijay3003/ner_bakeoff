\# Local NER Bake-off: Recommendation and Findings



\## 1. Objective and Results



I compared three locally running Named Entity Recognition (NER) models on 50 test snippets: spaCy `en\_core\_web\_sm`, GLiNER `urchade/gliner\_small-v2.1`, and Qwen3 1.7B through Ollama. I evaluated them using exact entity-text and label matching.



Qwen3 achieved the highest overall F1 score of \*\*0.867\*\*, followed by GLiNER at \*\*0.788\*\* and spaCy at \*\*0.538\*\*. However, Qwen3 was much slower, taking a median of 45.31 seconds per snippet. GLiNER took 0.62 seconds, while spaCy took only 0.018 seconds.



\## 2. Recommendation



For a customer prioritising low cost and speed, I would choose \*\*spaCy\*\* when its accuracy is sufficient. For a balance between accuracy and latency, I would consider \*\*GLiNER\*\*, which achieved an F1 score of 0.788 with a median latency of approximately 0.62 seconds.



For a customer prioritising accuracy, \*\*Qwen3 1.7B\*\* is the strongest model in this experiment. Its high latency, however, makes it less suitable for processing large volumes of snippets without further optimisation.



\## 3. Observed Failure Patterns



The models sometimes identified the right words but predicted incorrect entity boundaries or labels.



\- In snippet `t06`, GLiNER predicted “mumbai office” as an organisation instead of identifying “mumbai” as a location.

\- In snippet `t06`, Qwen3 missed the location “mumbai” and the person “rohan mehta”.

\- In snippet `t23`, Qwen3 predicted “singapore grand prix” instead of the full event name “formula 1 singapore grand prix”.



These examples show that entity boundaries and complete name recognition remain challenging, even when a model understands the general context.



\## 4. Next Steps



With another day, I would evaluate more examples, investigate entity-boundary errors, and test alternative GLiNER thresholds and LLM prompts using only the development dataset. I would also measure total Ollama memory usage more carefully and explore batching or faster inference configurations.



\## 5. Limitations and Cost Estimate



The test set contains only 50 snippets, so these results are an initial comparison rather than proof of general performance. The scores depend on the dataset, model versions, and configurations used. Exact-match scoring penalises predictions that contain only part of the correct entity name.



The cost estimate assumes an AWS c6i.xlarge Linux on-demand instance at \*\*$0.17 per hour\*\*. The calculation uses average processing time per snippet multiplied by 1,000, then converts seconds to hours and multiplies by the hourly rate. Estimated costs are $0.0009 for spaCy, $0.0291 for GLiNER, and $2.1016 for Qwen3 per 1,000 snippets.



These estimates exclude idle time, engineering effort, storage, network costs, and potential batching improvements. Latency was measured on my laptop rather than the AWS instance, so actual cloud performance may differ. Memory figures are approximate, particularly for Ollama because the model runs in a separate serving process.



I inspected test-set errors to understand the observed failure patterns. The reported test scores should therefore be treated as the benchmark results for the configurations evaluated, not as results from subsequent tuning.





