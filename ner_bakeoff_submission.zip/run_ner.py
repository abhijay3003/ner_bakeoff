"""Run ONE model over ONE dataset and save predictions + timing + memory.

Examples (run from the project folder in cmd):
    python run_ner.py --model spacy  --name spacy_sm  --data data/dev.jsonl
    python run_ner.py --model gliner --name gliner_s  --data data/dev.jsonl --threshold 0.4
    python run_ner.py --model ollama --name qwen3_1.7b --ollama-model qwen3:1.7b --data data/dev.jsonl

Outputs (in the results/ folder):
    <split>_<name>.jsonl        predictions in the format score.py expects
    <split>_<name>.stats.json   latency, memory, hardware, settings
"""
import argparse
import os
import platform
import time

import psutil

from ner_models import GlinerNER, OllamaNER, SpacyNER
from utils import (MemoryMonitor, clean_entities, latency_stats, read_jsonl,
                   write_jsonl)

WARMUP_TEXT = "Maria Lopez joined Acme Corp in Paris during the Spring Summit."
WARMUP_RUNS = 2


def build_model(args):
    """Create the wrapper object chosen on the command line."""
    if args.model == "gliner":
        return GlinerNER(threshold=args.threshold)
    if args.model == "spacy":
        return SpacyNER(model_name=args.spacy_model)
    return OllamaNER(model_name=args.ollama_model, url=args.ollama_url)


def hardware_info():
    """Basic machine description for the report."""
    return {
        "cpu": platform.processor(),
        "cpu_cores_logical": psutil.cpu_count(logical=True),
        "ram_gb": round(psutil.virtual_memory().total / 1024 ** 3, 1),
        "os": platform.platform(),
        "python": platform.python_version(),
    }


def main():
    ap = argparse.ArgumentParser(description="Run one NER model on one dataset.")
    ap.add_argument("--model", required=True, choices=["gliner", "spacy", "ollama"])
    ap.add_argument("--name", required=True, help="short label used in file names")
    ap.add_argument("--data", required=True, help="e.g. data/dev.jsonl")
    ap.add_argument("--outdir", default="results")
    ap.add_argument("--threshold", type=float, default=0.5, help="GLiNER only")
    ap.add_argument("--spacy-model", default="en_core_web_sm", help="spaCy only")
    ap.add_argument("--ollama-model", default="qwen3:1.7b", help="Ollama only")
    ap.add_argument("--ollama-url", default="http://localhost:11434")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    split = os.path.splitext(os.path.basename(args.data))[0]   # "dev" or "test"
    pred_path = os.path.join(args.outdir, f"{split}_{args.name}.jsonl")
    stats_path = os.path.join(args.outdir, f"{split}_{args.name}.stats.json")

    snippets = read_jsonl(args.data)
    model = build_model(args)

    print(f"Loading model: {args.model} ...")
    model.load()                       # not timed

    # Start measuring memory AFTER load() but BEFORE warm-up.
    # (Ollama only loads its model during the first request.)
    monitor = MemoryMonitor(include_ollama=(args.model == "ollama"))
    monitor.start()

    print(f"Warm-up ({WARMUP_RUNS} runs, not timed) ...")
    for _ in range(WARMUP_RUNS):
        model.predict(WARMUP_TEXT)
    # Warm-up must not count in LLM failure statistics.
    if hasattr(model, "parse_failures"):
        model.parse_failures = 0
        model.retries = 0

    print(f"Running on {len(snippets)} snippets from {args.data} ...")
    predictions, latencies = [], []
    for i, row in enumerate(snippets, 1):
        start = time.perf_counter()
        entities = model.predict(row["text"])       # <-- the timed part
        latencies.append(time.perf_counter() - start)
        predictions.append({"id": row["id"], "entities": clean_entities(entities)})
        print(f"  [{i}/{len(snippets)}] {row['id']}  {latencies[-1]:.2f}s  "
              f"{len(predictions[-1]['entities'])} entities")

    peak_mb = monitor.stop()
    write_jsonl(pred_path, predictions)

    stats = {
        "name": args.name,
        "data": args.data,
        "snippets": len(snippets),
        "predictions_file": pred_path,
        "model": model.describe(),
        "peak_memory_mb": round(peak_mb, 1),
        "hardware": hardware_info(),
    }
    stats.update(latency_stats(latencies))
    if hasattr(model, "extra_stats"):
        stats.update(model.extra_stats())

    import json
    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2)

    print(f"\nSaved predictions: {pred_path}")
    print(f"Saved stats:       {stats_path}")
    print(f"median {stats['median_s']}s | p95 {stats['p95_s']}s | peak RAM {stats['peak_memory_mb']} MB")


if __name__ == "__main__":
    main()
