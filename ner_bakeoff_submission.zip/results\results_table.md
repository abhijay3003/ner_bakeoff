

|Model|F1 overall|PERSON|ORG|LOCATION|EVENT|median s|p95 s|peak RAM MB|$/1000 snippets|
|-|-|-|-|-|-|-|-|-|-|
|spacy\_sm|0.538|0.727|0.379|0.632|0.105|0.018|0.0223|286.0|0.0009|
|gliner\_s|0.788|0.746|0.712|0.941|0.632|0.6206|0.7369|1244.4|0.0291|
|llm|0.867|0.917|0.792|0.902|0.812|45.3118|61.1285|1600|2.1016|

Models:

* spacy\_sm: {"type": "specialist", "model": "en\_core\_web\_sm", "version": "3.8.16"}
* gliner\_s: {"type": "specialist", "model": "urchade/gliner\_small-v2.1", "threshold": 0.5}
* llm: {"type": "local LLM (Ollama)", "model": "qwen3:1.7b", "parameter\_size": "2.0B", "quantization": "Q4\_K\_M", "temperature": 0} (LLM parse failures: 0, retries: 0)

Cost assumption: $0.17/hour, one snippet at a time.

