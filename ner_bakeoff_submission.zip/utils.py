"""Small helper functions shared by the scripts.

Nothing here is model specific. It covers:
  * reading / writing .jsonl files
  * cleaning predicted entities (same rules for every model, so it is fair)
  * measuring peak memory while a model runs
  * simple latency statistics
"""
import json
import math
import re
import threading
import time

import psutil

# Leading titles that are NOT part of a person's name (assignment rule).
# Only applied to PERSON entities.
HONORIFICS = {
    "dr", "mr", "mrs", "ms", "prof", "professor",
    "minister", "mayor", "senator", "president",
}


# --------------------------------------------------------------------------
# File helpers
# --------------------------------------------------------------------------
def read_jsonl(path):
    """Read a .jsonl file and return a list of dicts (one per line)."""
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def write_jsonl(path, rows):
    """Write a list of dicts to a .jsonl file (one JSON object per line)."""
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


# --------------------------------------------------------------------------
# Entity cleaning (applied to every model's output)
# --------------------------------------------------------------------------
def clean_entities(entities):
    """Apply the assignment's normalisation rules to a list of entities.

    Rules:
      1. Strip whitespace and surrounding quotes / trailing punctuation.
      2. Strip possessives:  "Singapore's" -> "Singapore".
      3. Strip leading honorifics from PERSON:  "Dr. Marcus Teo" -> "Marcus Teo".
      4. Remove duplicates (same text + label, case-insensitive).
    """
    cleaned = []
    seen = set()
    for ent in entities:
        text = str(ent.get("text", "")).strip()
        label = str(ent.get("label", "")).strip().upper()

        text = text.strip("\"'\u201c\u201d\u2018\u2019 ,;:!?")           # rule 1
        text = re.sub(r"[\u2019']s$", "", text)                           # rule 2

        if label == "PERSON":                                             # rule 3
            words = text.split()
            while len(words) > 1 and words[0].lower().rstrip(".") in HONORIFICS:
                words = words[1:]
            text = " ".join(words)

        if not text:
            continue
        key = (text.lower(), label)                                       # rule 4
        if key in seen:
            continue
        seen.add(key)
        cleaned.append({"text": text, "label": label})
    return cleaned


# --------------------------------------------------------------------------
# Memory measurement
# --------------------------------------------------------------------------
class MemoryMonitor:
    """Samples RAM in a background thread and remembers the peak.

    For Ollama the model lives in a separate process, so with
    include_ollama=True we also add the memory of every process whose name
    contains "ollama".
    """

    def __init__(self, include_ollama=False, interval=0.2):
        self.include_ollama = include_ollama
        self.interval = interval
        self.peak_mb = 0.0
        self._stop = threading.Event()
        self._thread = None
        self._me = psutil.Process()

    def _current_mb(self):
        total = self._me.memory_info().rss
        if self.include_ollama:
            for proc in psutil.process_iter(["name", "memory_info"]):
                try:
                    name = (proc.info["name"] or "").lower()
                    mem = proc.info["memory_info"]
                    if "ollama" in name and mem is not None:
                        total += mem.rss
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        return total / (1024 * 1024)

    def _loop(self):
        while not self._stop.is_set():
            self.peak_mb = max(self.peak_mb, self._current_mb())
            time.sleep(self.interval)

    def start(self):
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        """Stop sampling and return the peak in MB."""
        self._stop.set()
        self._thread.join()
        self.peak_mb = max(self.peak_mb, self._current_mb())
        return self.peak_mb


# --------------------------------------------------------------------------
# Latency statistics
# --------------------------------------------------------------------------
def percentile(values, pct):
    """Nearest-rank percentile (pct between 0 and 100)."""
    ordered = sorted(values)
    rank = max(1, math.ceil(pct / 100 * len(ordered)))
    return ordered[rank - 1]


def latency_stats(latencies):
    """Return median, p95, mean and total of a list of seconds."""
    ordered = sorted(latencies)
    mid = len(ordered) // 2
    median = ordered[mid] if len(ordered) % 2 else (ordered[mid - 1] + ordered[mid]) / 2
    return {
        "median_s": round(median, 4),
        "p95_s": round(percentile(latencies, 95), 4),
        "mean_s": round(sum(latencies) / len(latencies), 4),
        "total_s": round(sum(latencies), 2),
    }
