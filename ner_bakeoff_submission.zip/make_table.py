"""Build the final results table from the stats files + score.py output.

Example:
    python make_table.py --gold data/test.jsonl ^
        --stats results/test_gliner_s.stats.json results/test_spacy_sm.stats.json ^
        --price-per-hour 0.17

(^ is the line-continuation character in Windows cmd. You can also put it on one line.)

Cost model (simple on purpose):
    cost per 1000 snippets = mean seconds per snippet * 1000 / 3600 * price per hour
It assumes one machine processes one snippet at a time, 100% busy.
"""
import argparse
import json
import subprocess
import sys

LABELS = ["PERSON", "ORG", "LOCATION", "EVENT", "MICRO-ALL"]


def run_score(gold, pred):
    """Run score.py (unmodified) and return {label: F1}, plus raw output."""
    out = subprocess.run([sys.executable, "score.py", gold, pred],
                         capture_output=True, text=True, encoding="utf-8").stdout
    f1 = {}
    for line in out.splitlines():
        parts = line.split()
        # rows look like: LABEL P R F1 TP FP FN
        if len(parts) == 7 and parts[0] in LABELS:
            f1[parts[0]] = float(parts[3])
    return f1, out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gold", required=True)
    ap.add_argument("--stats", nargs="+", required=True)
    ap.add_argument("--price-per-hour", type=float, required=True,
                    help="USD per hour of the cloud machine you assume")
    ap.add_argument("--out", default="results/results_table.md")
    args = ap.parse_args()

    header = ("| Model | F1 overall | PERSON | ORG | LOCATION | EVENT | "
              "median s | p95 s | peak RAM MB | $/1000 snippets |")
    lines = [header, "|" + "---|" * 10]
    details = []
    for path in args.stats:
        with open(path, encoding="utf-8") as f:
            s = json.load(f)
        f1, raw = run_score(args.gold, s["predictions_file"])
        cost = s["mean_s"] * 1000 / 3600 * args.price_per_hour
        lines.append(
            f"| {s['name']} | {f1.get('MICRO-ALL', 0):.3f} | {f1.get('PERSON', 0):.3f} | "
            f"{f1.get('ORG', 0):.3f} | {f1.get('LOCATION', 0):.3f} | {f1.get('EVENT', 0):.3f} | "
            f"{s['median_s']} | {s['p95_s']} | {s['peak_memory_mb']} | {cost:.4f} |"
        )
        extra = ""
        if "llm_parse_failures" in s:
            extra = (f" (LLM parse failures: {s['llm_parse_failures']}, "
                     f"retries: {s['llm_retries']})")
        details.append(f"- {s['name']}: {json.dumps(s['model'])}{extra}")

    text = "\n".join(lines) + "\n\nModels:\n" + "\n".join(details) + "\n"
    text += f"\nCost assumption: ${args.price_per_hour}/hour, one snippet at a time.\n"
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(text)
    print(text)
    print(f"Saved: {args.out}")


if __name__ == "__main__":
    main()
