"""The three model wrappers (adapters).

Every wrapper has the same three methods, so run_ner.py can treat them alike:
    load()          -> load the model into memory (NOT timed)
    predict(text)   -> return a list of {"text": ..., "label": ...}
    describe()      -> return a dict with model name / settings for the report
"""
import json
import re

# The four labels we are allowed to output.
LABELS = ["PERSON", "ORG", "LOCATION", "EVENT"]


# ==========================================================================
# 1. GLiNER  (specialist, zero-shot: we give it label names in plain words)
# ==========================================================================
class GlinerNER:
    # GLiNER works better with natural words than with "ORG", so we map back.
    PROMPT_TO_LABEL = {
        "person": "PERSON",
        "organization": "ORG",
        "location": "LOCATION",
        "event": "EVENT",
    }

    def __init__(self, model_name="urchade/gliner_small-v2.1", threshold=0.5):
        self.model_name = model_name
        self.threshold = threshold  # lower = more entities (more recall)
        self.model = None

    def load(self):
        from gliner import GLiNER  # imported here so other models don't need it
        self.model = GLiNER.from_pretrained(self.model_name)

    def predict(self, text):
        found = self.model.predict_entities(
            text, list(self.PROMPT_TO_LABEL.keys()), threshold=self.threshold
        )
        return [
            {"text": e["text"], "label": self.PROMPT_TO_LABEL[e["label"]]}
            for e in found
        ]

    def describe(self):
        return {"type": "specialist", "model": self.model_name,
                "threshold": self.threshold}


# ==========================================================================
# 2. spaCy  (specialist, fixed label set -> we map its labels to ours)
# ==========================================================================
class SpacyNER:
    # spaCy label -> our label. Anything not listed (DATE, MONEY, NORP...) is ignored.
    LABEL_MAP = {
        "PERSON": "PERSON",
        "ORG": "ORG",
        "GPE": "LOCATION",   # countries, cities
        "LOC": "LOCATION",   # mountains, rivers...
        "FAC": "LOCATION",   # buildings, landmarks
        "EVENT": "EVENT",
    }

    def __init__(self, model_name="en_core_web_sm"):
        self.model_name = model_name
        self.nlp = None

    def load(self):
        import spacy
        self.nlp = spacy.load(self.model_name)

    def predict(self, text):
        doc = self.nlp(text)
        return [
            {"text": ent.text, "label": self.LABEL_MAP[ent.label_]}
            for ent in doc.ents
            if ent.label_ in self.LABEL_MAP
        ]

    def describe(self):
        return {"type": "specialist", "model": self.model_name,
                "version": self._version()}

    @staticmethod
    def _version():
        import spacy
        return spacy.__version__


# ==========================================================================
# 3. Local LLM through Ollama's HTTP API
# ==========================================================================
SYSTEM_PROMPT = """You are a named entity recognition tool.
Find named entities in the text and return them as JSON.

Labels:
- PERSON: names of individual people. Do NOT include titles (Dr., Minister, Chef...). Example: "Minister Daniel Koh" -> "Daniel Koh".
- ORG: companies, agencies, institutions, schools, clubs, teams, media outlets.
- LOCATION: countries, cities, districts, rivers, mountains, landmarks, venues, buildings.
- EVENT: NAMED events only (festivals, tournaments, summits, holidays, storms). Not generic ones like "the match".

Rules:
- Use the longest name only. "Busan International Film Festival" is one EVENT, do not also tag "Busan".
- Do NOT tag nationalities ("Jordanian"), dates, numbers or job titles.
- Do NOT tag titles of films, books or songs, even if they contain a place or person name.
- Remove possessives: "Singapore's" -> "Singapore".
- List each entity once. Copy the text exactly as written in the input.
- If there are no entities, return {"entities": []}.

Example 1
Text: Minister Lena Ortiz opened the Harvest Fair in Bristol, her aides said.
Output: {"entities": [{"text": "Lena Ortiz", "label": "PERSON"}, {"text": "Harvest Fair", "label": "EVENT"}, {"text": "Bristol", "label": "LOCATION"}]}

Example 2
Text: The film "Night Train to Lisbon" got mixed reviews last week.
Output: {"entities": []}
"""

# Ollama can force the model to answer in this exact JSON shape.
RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "entities": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "text": {"type": "string"},
                    "label": {"type": "string", "enum": LABELS},
                },
                "required": ["text", "label"],
            },
        }
    },
    "required": ["entities"],
}


def parse_llm_output(raw):
    """Turn the model's raw reply into a list of entities.

    Returns None if the reply is unusable (so the caller can retry / count it).
    Tolerates chatty replies by looking for the first {...} block.
    """
    data = None
    try:
        data = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        match = re.search(r"\{.*\}", raw or "", re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(0))
            except json.JSONDecodeError:
                return None
    if isinstance(data, dict):
        data = data.get("entities")
    if not isinstance(data, list):
        return None
    # Keep only well-formed items.
    return [
        {"text": e["text"], "label": e["label"]}
        for e in data
        if isinstance(e, dict) and "text" in e and "label" in e
    ]


class OllamaNER:
    def __init__(self, model_name="qwen3:1.7b", url="http://localhost:11434",
                 max_attempts=2, timeout=300):
        self.model_name = model_name
        self.url = url.rstrip("/")
        self.max_attempts = max_attempts   # 1 first try + retries
        self.timeout = timeout             # seconds per request
        self.parse_failures = 0            # snippets where every attempt failed
        self.retries = 0                   # extra attempts that were needed
        self.use_think_flag = True         # switched off if the model rejects it
        self.model_details = {}

    def load(self):
        """Nothing to load here: Ollama loads the model on the first request
        (that happens during the warm-up, which is not timed)."""
        import requests
        try:
            r = requests.post(f"{self.url}/api/show",
                              json={"model": self.model_name}, timeout=30)
            r.raise_for_status()
            self.model_details = r.json().get("details", {})
        except requests.RequestException as err:
            raise SystemExit(
                f"Cannot reach Ollama or model '{self.model_name}' ({err}).\n"
                f"Is Ollama running? Did you run: ollama pull {self.model_name}"
            )

    def _ask(self, text):
        """Send one request and return the raw reply text."""
        import requests
        payload = {
            "model": self.model_name,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Text: {text}\nOutput:"},
            ],
            "stream": False,
            "format": RESPONSE_SCHEMA,       # force valid JSON
            "keep_alive": "30m",             # keep model in RAM between calls
            "options": {"temperature": 0, "num_predict": 400, "num_ctx": 2048},
        }
        if self.use_think_flag:
            payload["think"] = False         # switch off Qwen3 "thinking" (slow)
        r = requests.post(f"{self.url}/api/chat", json=payload, timeout=self.timeout)
        if r.status_code == 400 and self.use_think_flag:
            # Some models do not know the "think" option -> retry without it.
            self.use_think_flag = False
            return self._ask(text)
        r.raise_for_status()
        return r.json()["message"]["content"]

    def predict(self, text):
        for attempt in range(1, self.max_attempts + 1):
            entities = parse_llm_output(self._ask(text))
            if entities is not None:
                return entities
            if attempt < self.max_attempts:
                self.retries += 1
        self.parse_failures += 1   # gave up: counts as "no entities"
        return []

    def describe(self):
        return {
            "type": "local LLM (Ollama)",
            "model": self.model_name,
            "parameter_size": self.model_details.get("parameter_size"),
            "quantization": self.model_details.get("quantization_level"),
            "temperature": 0,
        }

    def extra_stats(self):
        return {"llm_parse_failures": self.parse_failures,
                "llm_retries": self.retries}
