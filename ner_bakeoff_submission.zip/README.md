# Local NER bake-off

Compares 3 models on the same NER task, all on CPU:

| Name | Kind | Model |
|---|---|---|
| `spacy_sm` | specialist, fixed labels | spaCy `en_core_web_sm` |
| `gliner_s` | specialist, zero-shot | `urchade/gliner_small-v2.1` |
| `llm` | local LLM | `qwen3:1.7b` (Ollama, Q4) |

To compare a bigger LLM, run the Ollama command again with another tag, e.g. `qwen3:4b`, and a new `--name`.

## Files

| File | What it does |
|---|---|
| `run_ner.py` | Runs ONE model on ONE dataset. Times each snippet, measures peak RAM, writes predictions. |
| `ner_models.py` | The 3 model wrappers + the LLM prompt + JSON parsing. |
| `utils.py` | Entity cleaning, memory monitor, latency stats. |
| `make_table.py` | Runs `score.py` and builds the results table with cost. |
| `score.py` | Provided scorer. Not modified. |
| `run_dev.bat` / `run_test.bat` | One-click runs for dev and test. |

## Setup (Windows cmd, Python 3.11 or 3.12)

1. Create an environment, from the project folder:
   ```
   python -m venv venv
   venv\Scripts\activate
   ```
2. Install torch (CPU build) first, then the rest:
   ```
   pip install torch --index-url https://download.pytorch.org/whl/cpu
   pip install -r requirements.txt
   python -m spacy download en_core_web_sm
   ```
3. Install Ollama from https://ollama.com, then:
   ```
   ollama pull qwen3:1.7b
   ```
   Make sure the Ollama app is running (tray icon).
4. First GLiNER run downloads its weights from Hugging Face (needs internet once).

## Run

Close the browser and other heavy apps first (8 GB RAM, results are cleaner).

```
run_dev.bat
```
Look at the dev errors, change `GLINER_THRESHOLD` or the prompt in `ner_models.py`, run again. Tune on dev ONLY.

When finished tuning:
```
run_test.bat
```
Run it once. Outputs are in `results\`:
- `results_table.md`: the table for your report
- `test_<name>.stats.json`: latency, memory, hardware, LLM parse failures
- `test_<name>.errors.txt`: every false positive / false negative

Single model by hand:
```
python run_ner.py --model spacy --name spacy_sm --data data/dev.jsonl
python score.py data/dev.jsonl results/dev_spacy_sm.jsonl --errors
```

## How measurements work

- **Latency:** time around `predict()` for each snippet. Model load and 2 warm-up calls are excluded. Report median and p95.
- **Memory:** peak RAM sampled every 0.2 s from after load, including warm-up. For Ollama it adds all `ollama*` processes.
- **Cost per 1000 snippets:** `mean seconds per snippet * 1000 / 3600 * price per hour`. Cost leaves out: idle time, setup and engineering time, storage, network, batching gains, and the fact that latency was measured on this laptop, not on the cloud machine.
- **Cleaning (same for all models):** strip possessives, strip leading honorifics from PERSON, remove duplicates (`utils.clean_entities`).
- **LLM failures:** the LLM is forced into a JSON schema. If the reply is still unusable it retries once. If that fails too, the snippet counts as no entities, and the count is saved in the stats file.

## Assumptions

- spaCy labels mapped: GPE, LOC, FAC to LOCATION; PERSON, ORG, EVENT kept; the rest ignored.
- Qwen3 "thinking" is switched off (`think: false`) to keep latency low.
- Temperature 0, so LLM runs are close to repeatable.

## AI-assistant disclosure

AI assistance was used to help structure the benchmark code, explain implementation choices, debug issues, and improve documentation. The code was run locally, and the reported evaluation results were obtained from the benchmark runs on my laptop. I reviewed the implementation and results before preparing the submission.