@echo off
REM Runs all 3 models ONCE on the TEST set (50 snippets) and builds the results table.
REM Use the SAME settings you finalised on dev.
set GLINER_THRESHOLD=0.5
set OLLAMA_MODEL=qwen3:1.7b
REM Hourly price (USD) of the cloud machine you assume. Replace with a real, sourced number.
set PRICE_PER_HOUR=0.17

python run_ner.py --model spacy  --name spacy_sm   --data data/test.jsonl
python run_ner.py --model gliner --name gliner_s   --data data/test.jsonl --threshold %GLINER_THRESHOLD%
python run_ner.py --model ollama --name llm        --data data/test.jsonl --ollama-model %OLLAMA_MODEL%

python make_table.py --gold data/test.jsonl --price-per-hour %PRICE_PER_HOUR% --stats results/test_spacy_sm.stats.json results/test_gliner_s.stats.json results/test_llm.stats.json

echo.
echo Per-error lists (for your failure analysis):
for %%N in (spacy_sm gliner_s llm) do (
  python score.py data/test.jsonl results/test_%%N.jsonl --errors > results/test_%%N.errors.txt
)
echo Saved results\test_*.errors.txt
