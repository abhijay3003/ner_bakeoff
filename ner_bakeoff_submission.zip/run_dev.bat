@echo off
REM Runs all 3 models on the DEV set (10 snippets). Use this to tune settings.
REM Change the settings below, run again, compare. Never tune on test.
set GLINER_THRESHOLD=0.5
set OLLAMA_MODEL=qwen3:1.7b

python run_ner.py --model spacy  --name spacy_sm   --data data/dev.jsonl
python run_ner.py --model gliner --name gliner_s   --data data/dev.jsonl --threshold %GLINER_THRESHOLD%
python run_ner.py --model ollama --name llm        --data data/dev.jsonl --ollama-model %OLLAMA_MODEL%

echo.
echo ===== DEV scores =====
for %%N in (spacy_sm gliner_s llm) do (
  echo --- %%N ---
  python score.py data/dev.jsonl results/dev_%%N.jsonl --errors
)
